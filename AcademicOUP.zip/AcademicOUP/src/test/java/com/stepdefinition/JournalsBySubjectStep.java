package com.stepdefinition;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.base.Library;
import com.pages.JournalsBySubject;
import com.pages.LoginAcademicOUP;
import com.seleniumutility.SeleUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class JournalsBySubjectStep extends Library
{
	SeleUtil util;
	JournalsBySubject subject;
	Logger LOG = Logger.getLogger(LoginAcademicOUP.class.getName());
	
	//Launching the Browser 
	@Given("^I launch the webbrowser$")
	public void i_launch_the_webbrowser() throws IOException 
	{
	   
		launchBrowser(); 
		LOG.info("Browser is Launched");
		System.out.println("Browser is Launched");	
		
	}
	
	//Taking the ScreenShot
	@When("^JournalsBySubject page is Opened$")
	public void journalsbysubject_page_is_Opened() 
	{
		
		util = new SeleUtil(driver);
		util.ScreenShot("C:\\Users\\lenovo\\eclipse-workspace1\\AcademicOUP\\src\\test\\resources\\ScreenShot\\JournalsBySubject.png");
		LOG.info("ScreenShot took Successfully");
		System.out.println("ScreenShot is Successfully Taken");
	   
	}
	
	//Clicking on the buttons
    @Then("^I click on that button$")
	public void i_click_on_that_button() 
	{
		subject = new JournalsBySubject(driver);
		subject.journals_bysubject();
		 System.out.println("Clicked on JournalsBySubject and its sub Medicine&Health buttons");
       LOG.info("mouse is Journals By Subject  button and clicked on Medical & Health Button");
	
	}

}
