package com.stepdefinition;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.base.Library;
import com.pages.CustomerServices;
import com.pages.LoginAcademicOUP;
import com.seleniumutility.SeleUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerServicesStep extends Library
{
	
	SeleUtil util;
	CustomerServices service;
	
	Logger LOG = Logger.getLogger(LoginAcademicOUP.class.getName());	

	//Launching the browser
      @Given("^I launch the browser$")
         public void i_launch_the_browser() throws IOException 
           {
	              launchBrowser(); 
	              LOG.info("Browser is launched");
	              System.out.println("Browser is Launched");
           }
      
    //Taking the ScreenShot
       @When("^Customer Service Page is Opened$")
         public void customer_Service_Page_is_Opened() 
          {
	         util = new SeleUtil(driver);
	         util.ScreenShot("C:\\Users\\lenovo\\eclipse-workspace1\\AcademicOUP\\src\\test\\resources\\ScreenShot\\CustomerServices.png");
	         LOG.info("ScreenShot took Successfully");
	         System.out.println("ScreenShot is Successfully Taken");
          }
       
     //Clicks the buttons
         @Then("^I Click on that button$")
              public void i_Click_on_that_button() 
                {
	               service = new CustomerServices(driver);
                   service.customer_serviceinspect();
                   System.out.println("Clicked on Customer Services and its sub Aboutus buttons");
                   LOG.info("mouse is moved on customer service button");
                   LOG.info("Clicked about us button");
                }



}
