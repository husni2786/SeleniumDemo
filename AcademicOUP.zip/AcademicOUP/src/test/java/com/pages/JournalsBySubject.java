package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class JournalsBySubject 
{
	        WebDriver driver;
	        Actions action;
			
			//Identifying the Loactors
			@FindBy(linkText = "Journals by Subject")
			WebElement journals;
			@FindBy(linkText ="Medicine & Health")
			WebElement medicine;
			
			//Pointing to the Current Browser
			public JournalsBySubject(WebDriver driver)
			{
				
				PageFactory.initElements(driver, this);
				this.driver=driver;
			}
			
			//Performing the mouse mover operation and click on the submenu
			public void journals_bysubject()
			{
				
				  action = new Actions(driver);
				  action.moveToElement(journals).build().perform();
				  Actions seriesofactions = action.moveToElement(medicine).click();
				  seriesofactions.build().perform();
			}
			
			

		}






