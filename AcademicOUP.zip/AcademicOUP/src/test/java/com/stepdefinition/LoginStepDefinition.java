package com.stepdefinition;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.base.Library;
import com.excelutility.ExcelUtil;
import com.pages.LoginAcademicOUP;
import com.seleniumutility.SeleUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition extends Library
{
	Logger LOG = LogManager.getLogger(LoginAcademicOUP.class.getName());
	
	SeleUtil util;
	LoginAcademicOUP login;
	ExcelUtil excel=new ExcelUtil(driver);

	//Launching the Browser
	@Given("^I launch the browser and enter the url$")
	public void i_launch_the_browser_and_enter_the_url() throws IOException 
	{
		launchBrowser();
		LOG.info("Browser is Opened");
		System.out.println("Browser is Launched");
		login = new LoginAcademicOUP(driver);
	}
	
     //Taking ScreenShots
	@When("^login page is opened$")
	public void login_page_is_opened() 
	{
		util = new SeleUtil(driver);
		util.ScreenShot("C:\\Users\\lenovo\\eclipse-workspace1\\AcademicOUP\\src\\test\\resources\\ScreenShot\\LoginAcademicOUP.png");
		LOG.info("ScreenShot took Successfully");
		System.out.println("ScreenShot is Successfully Taken");
	   
	}
	
	//Entering Username and Password
    @Then("^I enter the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_the_and(String username, String  password) 
	{
	       login.login_signininspect();
		   try 
		   {
			login.login_username(excel.excel_username(1));
		   } 
		   catch (IOException e) 
		   {
			e.printStackTrace();
		   }
		   try
		   {
			login.login_password(excel.excel_password(1));
		   } 
		   catch (IOException e) 
		   {
			e.printStackTrace();
		   }
		   LOG.info("Username and Password is entered in respected fields");
		   System.out.println("Username and password are entered");
	}

    //Click on the Signin Button
	@Then("^I click on the signin button$")
	public void i_click_on_the_signin_button() 
	{
		login.login_button();
		LOG.info("Login Button is Clicked");
		System.out.println("Signin Button is Clicked");
	}
	

}
